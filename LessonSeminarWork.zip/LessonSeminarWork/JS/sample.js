// Task_1
// alert('Hello, dear frends!');

// Task_4
// let first_name = 'Sam';
// function showMessage() {
//     let message = 'Hello, ' + first_name;
//     alert(message);
// }

// showMessage();

//Task_5
// u_q = confirm('Are you sure?')

// let age = parseInt(prompt('Add your age1'));

// if (age == 18) {
//     alert('Вы совершеннолетний, все можно!');
// } else if (age == 10) {
//     alert('Вам надо учить уроки!');
// } else if (age == 30) {
//     alert('Ложитесь спать, завтра на работу');
// } else {
//     alert('Мы не знаем что Вам делать');
// }

